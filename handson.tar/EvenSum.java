package javaApp;

public class EvenSum {

    public static void main(String[] args) {
        int num = Integer.parseInt(args[0]);
        int even[] = new int[num];
        int sum = 0,j = 0;
        String evennums = "";
        //Insert your code here
        for(int i=0;j<=num;j++)
	{
	   if(j%2==0)
	   {
		   even[i]=j;
		   sum=sum+j;
		   i++;
		   evennums=evennums+j;
		   if(num-j>1)
			   evennums=evennums+",";
		   //evennums=evennums.concat(j);
	   }
	}

        System.out.println(evennums);
        System.out.println(sum);
    }
}  

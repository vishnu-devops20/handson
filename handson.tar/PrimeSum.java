package javaApp;

public class PrimeSum {

    public static void main(String[] args) {
        System.out.println(primesum(20));
    }

    static long primesum(int maxNum) {
        int sum = 0, num, temp;
        int prime;
	//insert your code here
        if(maxNum<=0)
		return sum;
	else
	{
		for(num=2;num<=maxNum;num++)
		{
			//if (isPrime(num))
			//	sum=sum+num;
			prime = 1;
			for(int i=2;i<=num/2;i++)
			{	
           			temp=num%i;
	   			if(temp==0)
				{		
	      			        prime = 0;
					break;
	   			}
			}		
			if (prime==1)
			 sum=sum+num;	
		}
	}

        return sum;
    }
} 

package javaApp;
public class Demo {

    public static void main(String[] args) {
      
        //Insert your code here
    System.out.println("Welcome to first maven war project");
    }

}
